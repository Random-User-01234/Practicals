from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

key = RSA.generate(2048)

private_key = key.export_key()
public_key = key.publickey().export_key()

original_document = b"This is original document."
modified_document = b"This is modified document."

original_hash = SHA256.new(original_document)
modified_hash = SHA256.new(modified_document)

signature = pkcs1_15.new(RSA.import_key(private_key)).sign(original_hash)

try:
    pkcs1_15.new(RSA.import_key(public_key)).verify(modified_hash, signature)
    print("Signature is valid: ")
except (ValueError, TypeError):
    print("Signature is invalid: ")
