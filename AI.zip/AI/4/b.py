from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X,y,test_size=0.3, random_state=1
)

model = MLPClassifier(hidden_layer_sizes=(5),
            max_iter=500,
            random_state=1
)

model.fit(X_train, y_train)

print("Model Trained Successfully")
