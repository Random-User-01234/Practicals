import pandas as pd 
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

df = pd.read_csv("SVM_Binary_Classification_Dataset.csv")

X = df[["Hours_Studied", "Attendance"]]
y = df["Result"]

model = SVC()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

params = {
    "C":[0.1,1,10],
    "kernel":["linear","rbf"],
    "gamma":["scale","auto"]
}

grid = GridSearchCV(model,params, cv=3)
grid.fit(X_train,y_train)

y_pred = grid.predict(X_test)

print("Best Parameters: ", grid.best_params_)
print("Accuracy: ", accuracy_score(y_test, y_pred) * 100, "%")
