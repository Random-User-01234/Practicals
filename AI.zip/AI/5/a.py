import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

df = pd.read_csv("SVM_Binary_Classification_Dataset.csv")

X = df[["Hours_Studied","Attendance"]]
y = df["Result"]

X_train, X_test, y_train, y_test = train_test_split(
    X,y,test_size=0.3, random_state=42
)

model = SVC(kernel="linear")
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Predicted: ", y_pred)
print("Actual: ", y_test.values)
print("Accuracy: ", accuracy_score(y_test, y_pred) * 100, "%")
