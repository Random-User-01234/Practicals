import pandas as pd 

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

df = pd.read_csv("SVM_Binary_Classification_Dataset.csv")

x = df[["Hours_Studied", "Attendance"]]
y = df["Result"]

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

model = SVC(kernel="linear")
model.fit(x_train, y_train)

y_pred = model.predict(x_test)

print("Actual: ", y_test.values)
print("Predicted: ", y_pred)
print("\nAccuracy: ", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix: \n", confusion_matrix(y_test, y_pred))
print("\nClassification Report: \n", classification_report(y_test, y_pred))


#done