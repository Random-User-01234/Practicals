import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier, plot_tree

data = pd.read_csv("play_tennis.csv")
data = pd.get_dummies(data)

X = data.drop("PlayTennis_Yes", axis=1)
y = data["PlayTennis_Yes"]

model = DecisionTreeClassifier()
model.fit(X, y)

plt.figure(figsize=(12,8))

plot_tree(
    model,
    feature_names = X.columns,
    class_names = ['No', 'Yes'],
    filled = True,
    rounded = True,
    fontsize = 9
)

plt.title("Decision Tree for Playing Tennis")
plt.show()

#done