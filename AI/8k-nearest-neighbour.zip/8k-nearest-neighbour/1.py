import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    roc_curve,
    roc_auc_score
)



plt.style.use("ggplot")

df = pd.read_csv("diabetes.csv")

print("First five rows of the dataset:")
print(df.head())

print("\nDataset shape:")
print(df.shape)

print("\nDataset data types:")
print(df.dtypes)



if "Outcome" not in df.columns:
    raise ValueError(
        "The file diabetes.csv must contain a column named 'Outcome'."
    )

X = df.drop("Outcome", axis=1).values
y = df["Outcome"].values



X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.4,
    random_state=42,
    stratify=y
)

print("\nTraining feature shape:", X_train.shape)
print("Testing feature shape:", X_test.shape)
print("Training target shape:", y_train.shape)
print("Testing target shape:", y_test.shape)



neighbors = np.arange(1, 10)
train_accuracy = np.empty(len(neighbors))
test_accuracy = np.empty(len(neighbors))

for i, k in enumerate(neighbors):
    knn = KNeighborsClassifier(n_neighbors=int(k))
    knn.fit(X_train, y_train)

    train_accuracy[i] = knn.score(X_train, y_train)
    test_accuracy[i] = knn.score(X_test, y_test)

print("\nAccuracy for different values of K:")
for i, k in enumerate(neighbors):
    print(
        f"K = {k}: "
        f"Training accuracy = {train_accuracy[i]:.4f}, "
        f"Testing accuracy = {test_accuracy[i]:.4f}"
    )



plt.figure()
plt.title("K-NN: Varying Number of Neighbors")
plt.plot(neighbors, test_accuracy, label="Testing Accuracy")
plt.plot(neighbors, train_accuracy, label="Training Accuracy")
plt.legend()
plt.xlabel("Number of Neighbors (K)")
plt.ylabel("Accuracy")
plt.xticks(neighbors)
plt.tight_layout()
plt.show()



knn = KNeighborsClassifier(n_neighbors=7)
knn.fit(X_train, y_train)

test_score = knn.score(X_test, y_test)
print("\nK-NN model accuracy with K = 7:", round(test_score, 4))



y_pred = knn.predict(X_test)

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))



print("\nClassification Report:")
print(classification_report(y_test, y_pred, zero_division=0))



y_pred_proba = knn.predict_proba(X_test)[:, 1]

fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)
auc_score = roc_auc_score(y_test, y_pred_proba)

print("\nROC AUC Score:", round(auc_score, 4))

plt.figure()
plt.plot(fpr, tpr, label=f"K-NN (AUC = {auc_score:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--", label="Random Classifier")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("K-NN ROC Curve")
plt.legend()
plt.tight_layout()
plt.show()



param_grid = {
    "n_neighbors": np.arange(1, 50)
}

knn_model = KNeighborsClassifier()
knn_cv = GridSearchCV(
    estimator=knn_model,
    param_grid=param_grid,
    cv=5,
    scoring="accuracy"
)

knn_cv.fit(X_train, y_train)

print("\nBest cross-validation accuracy:", round(knn_cv.best_score_, 4))
print("Best parameters:", knn_cv.best_params_)



best_knn = knn_cv.best_estimator_
best_predictions = best_knn.predict(X_test)

print("\nBest K-NN model test accuracy:", round(best_knn.score(X_test, y_test), 4))
print("\nConfusion Matrix for the Best Model:")
print(confusion_matrix(y_test, best_predictions))

print("\nClassification Report for the Best Model:")
print(classification_report(y_test, best_predictions, zero_division=0))
