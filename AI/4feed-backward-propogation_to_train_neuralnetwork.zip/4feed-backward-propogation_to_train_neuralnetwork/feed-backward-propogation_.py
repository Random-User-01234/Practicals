from sklearn.datasets import load_iris
from sklearn.neural_network import MLPClassifier

iris = load_iris()
X = iris.data
y = iris.target

model = MLPClassifier(hidden_layer_sizes=(5),
            max_iter=500,
            random_state=1
)

model.fit(X,y)

print("Training Completed Successfully")

#done