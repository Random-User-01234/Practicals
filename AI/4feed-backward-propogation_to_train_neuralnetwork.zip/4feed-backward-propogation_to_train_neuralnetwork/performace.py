from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score


iris = load_iris()

x=iris.data
y=iris.target

x_train,x_test,y_train,y_test = train_test_split(
    x, y, test_size=0.2, random_state=1
)

model = MLPClassifier(hidden_layer_sizes=(5),
    max_iter=500,
    random_state=1
)

model.fit(x_train, y_train)

y_pred = model.predict(x_test)
acc = accuracy_score(y_test, y_pred)

print("Accuracy: ", round(acc*100, 2), "%")

#done