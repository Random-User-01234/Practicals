import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB, CategoricalNB, GaussianNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, precision_score, recall_score, f1_score

df = pd.read_csv('diseases.csv')

print(df.head(11))
print(df.tail())
df.info()

le = LabelEncoder()

for col in df.columns:
    df[col] = le.fit_transform(df[col])

print(df.info())
print(df.head(11))

for col in df.columns:
    plt.figure(figsize=(6, 6))
    sns.countplot(x=df[col])
    plt.title(f"Category wise count of '{col}'")
    plt.xlabel("Category")
    plt.ylabel("Count")
    plt.show()

X = df.drop('Diagnosis', axis=1)
y = df['Diagnosis']

classifier = MultinomialNB()
classifier.fit(X, y)

classifier = CategoricalNB()
classifier.fit(X, y)

classifier = GaussianNB()
classifier.fit(X, y)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

classifier = MultinomialNB()
classifier.fit(X_train, y_train)
y_pred = classifier.predict(X_test)

print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average='macro', zero_division=0))
print("Recall:", recall_score(y_test, y_pred, average='macro', zero_division=0))
print("F1 Score:", f1_score(y_test, y_pred, average='macro', zero_division=0))
print("Classification Report:")
print(classification_report(y_test, y_pred, zero_division=0))

#done