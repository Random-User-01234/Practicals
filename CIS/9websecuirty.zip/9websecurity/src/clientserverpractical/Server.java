package clientserverpractical;

import java.net.*;
import java.io.*;

public class Server {

    public static void main(String[] args) throws Exception {

        Socket socket;

        ServerSocket serverSocket = new ServerSocket(8081);

        java.io.InputStreamReader insr = null;
        java.io.OutputStreamWriter oswr = null;
        java.io.BufferedReader br = null;
        java.io.BufferedWriter bw = null;

        System.out.println("Server waiting for client...");

        while (true) {

            socket = serverSocket.accept();

            System.out.println("Client connected!");

            insr = new InputStreamReader(socket.getInputStream());
            oswr = new OutputStreamWriter(socket.getOutputStream());

            br = new BufferedReader(insr);
            bw = new BufferedWriter(oswr);

            while (true) {

                String msgfromclient = br.readLine();

                if (msgfromclient == null) {
                    break;
                }

                System.out.println("Client: " + msgfromclient);

                System.out.println("Message Received");

                bw.write("You sent: " + msgfromclient);
                bw.newLine();
                bw.flush();

                if (msgfromclient.equalsIgnoreCase("BYE")) {
                    break;
                }
            }

            bw.close();
            br.close();
            socket.close();
        }
    }
}